import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Student {
  id: string;
  student_id: string;
  password: string;
  name: string;
  has_voted: boolean;
  created_at: string;
}

export interface Candidate {
  id: string;
  name: string;
  course: string;
  photo_url: string;
  vote_count: number;
  created_at: string;
}

export interface Vote {
  id: string;
  student_id: string;
  candidate_id: string;
  voted_at: string;
}

export interface Admin {
  id: string;
  username: string;
  password: string;
  created_at: string;
}
