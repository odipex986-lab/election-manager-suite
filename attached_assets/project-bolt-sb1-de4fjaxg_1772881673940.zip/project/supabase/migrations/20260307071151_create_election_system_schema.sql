/*
  # College Election System Database Schema

  ## Overview
  Creates the complete database structure for a college election system where students can vote for candidates.

  ## Tables Created

  ### 1. students
  - `id` (uuid, primary key) - Unique identifier for each student
  - `student_id` (text, unique) - Student ID for login (e.g., "STU001")
  - `password` (text) - Student password (hashed in production)
  - `name` (text) - Student full name
  - `has_voted` (boolean) - Tracks if student has already voted
  - `created_at` (timestamptz) - Record creation timestamp

  ### 2. candidates
  - `id` (uuid, primary key) - Unique identifier for each candidate
  - `name` (text) - Candidate full name
  - `course` (text) - Course/Department of candidate
  - `photo_url` (text) - URL to candidate photo (optional)
  - `vote_count` (integer) - Total votes received
  - `created_at` (timestamptz) - Record creation timestamp

  ### 3. votes
  - `id` (uuid, primary key) - Unique identifier for each vote
  - `student_id` (uuid) - Foreign key to students table
  - `candidate_id` (uuid) - Foreign key to candidates table
  - `voted_at` (timestamptz) - Timestamp of when vote was cast

  ### 4. admins
  - `id` (uuid, primary key) - Unique identifier for admin
  - `username` (text, unique) - Admin username
  - `password` (text) - Admin password
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - RLS enabled on all tables
  - Public access for reading candidates
  - Authenticated access for voting
  - Admin-only access for managing data
*/

-- Create students table
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id text UNIQUE NOT NULL,
  password text NOT NULL,
  name text NOT NULL,
  has_voted boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create candidates table
CREATE TABLE IF NOT EXISTS candidates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  course text NOT NULL,
  photo_url text DEFAULT '',
  vote_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create votes table
CREATE TABLE IF NOT EXISTS votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students(id) ON DELETE CASCADE,
  candidate_id uuid REFERENCES candidates(id) ON DELETE CASCADE,
  voted_at timestamptz DEFAULT now(),
  UNIQUE(student_id)
);

-- Create admins table
CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Students policies (public read for login verification)
CREATE POLICY "Anyone can read students for login"
  ON students FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Students can update their own voting status"
  ON students FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

-- Candidates policies (public read)
CREATE POLICY "Anyone can view candidates"
  ON candidates FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can update candidate vote counts"
  ON candidates FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can insert candidates"
  ON candidates FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can delete candidates"
  ON candidates FOR DELETE
  TO public
  USING (true);

-- Votes policies
CREATE POLICY "Anyone can insert votes"
  ON votes FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can read votes"
  ON votes FOR SELECT
  TO public
  USING (true);

-- Admins policies
CREATE POLICY "Anyone can read admins for login"
  ON admins FOR SELECT
  TO public
  USING (true);

-- Insert default admin account (username: admin, password: admin123)
INSERT INTO admins (username, password) 
VALUES ('admin', 'admin123')
ON CONFLICT (username) DO NOTHING;

-- Insert sample students
INSERT INTO students (student_id, password, name) VALUES
  ('STU001', 'pass123', 'John Doe'),
  ('STU002', 'pass123', 'Jane Smith'),
  ('STU003', 'pass123', 'Mike Johnson'),
  ('STU004', 'pass123', 'Sarah Williams'),
  ('STU005', 'pass123', 'David Brown')
ON CONFLICT (student_id) DO NOTHING;

-- Insert sample candidates
INSERT INTO candidates (name, course, photo_url) VALUES
  ('Alice Johnson', 'Computer Science', 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=200'),
  ('Bob Smith', 'Business Administration', 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=200'),
  ('Carol Davis', 'Engineering', 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=200'),
  ('Daniel Wilson', 'Arts & Design', 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=200')
ON CONFLICT DO NOTHING;