import { useState, useEffect } from 'react';
import { Trash2, UserPlus, RotateCcw, AlertCircle, CheckCircle } from 'lucide-react';
import { supabase, Candidate } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface AdminProps {
  onNavigate: (page: string) => void;
}

export default function Admin({ onNavigate }: AdminProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCandidate, setNewCandidate] = useState({
    name: '',
    course: '',
    photo_url: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { currentAdmin, logout } = useAuth();

  useEffect(() => {
    if (!currentAdmin) {
      onNavigate('admin-login');
      return;
    }
    loadCandidates();
  }, [currentAdmin, onNavigate]);

  const loadCandidates = async () => {
    try {
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .order('name');

      if (error) throw error;
      setCandidates(data || []);
    } catch (err) {
      setError('Failed to load candidates');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!newCandidate.name || !newCandidate.course) {
      setError('Name and course are required');
      return;
    }

    try {
      const { error } = await supabase.from('candidates').insert([
        {
          name: newCandidate.name,
          course: newCandidate.course,
          photo_url: newCandidate.photo_url,
          vote_count: 0,
        },
      ]);

      if (error) throw error;

      setSuccess('Candidate added successfully');
      setNewCandidate({ name: '', course: '', photo_url: '' });
      setShowAddForm(false);
      loadCandidates();
    } catch (err) {
      setError('Failed to add candidate');
      console.error(err);
    }
  };

  const handleDeleteCandidate = async (id: string) => {
    if (!confirm('Are you sure you want to delete this candidate?')) return;

    setError('');
    setSuccess('');

    try {
      const { error } = await supabase.from('candidates').delete().eq('id', id);

      if (error) throw error;

      setSuccess('Candidate deleted successfully');
      loadCandidates();
    } catch (err) {
      setError('Failed to delete candidate');
      console.error(err);
    }
  };

  const handleResetElection = async () => {
    if (
      !confirm(
        'Are you sure you want to reset the election? This will reset all votes and student voting status.'
      )
    ) {
      return;
    }

    setError('');
    setSuccess('');

    try {
      await supabase.from('votes').delete().neq('id', '00000000-0000-0000-0000-000000000000');

      await supabase
        .from('students')
        .update({ has_voted: false })
        .neq('id', '00000000-0000-0000-0000-000000000000');

      await supabase
        .from('candidates')
        .update({ vote_count: 0 })
        .neq('id', '00000000-0000-0000-0000-000000000000');

      setSuccess('Election reset successfully');
      loadCandidates();
    } catch (err) {
      setError('Failed to reset election');
      console.error(err);
    }
  };

  if (!currentAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Admin Panel</h1>
              <p className="text-gray-600 mt-1">
                Logged in as: <span className="font-semibold">{currentAdmin.username}</span>
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => onNavigate('results')}
                className="px-4 py-2 text-sm bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
              >
                View Results
              </button>
              <button
                onClick={() => {
                  logout();
                  onNavigate('home');
                }}
                className="px-4 py-2 text-sm bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4 flex items-start rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-6 bg-green-50 border-l-4 border-green-500 p-4 flex items-start rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-green-700">{success}</p>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-gray-800">Manage Candidates</h2>
            <div className="flex gap-3">
              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <UserPlus className="w-4 h-4" />
                Add Candidate
              </button>
              <button
                onClick={handleResetElection}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                Reset Election
              </button>
            </div>
          </div>

          {showAddForm && (
            <form onSubmit={handleAddCandidate} className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Candidate</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name *
                  </label>
                  <input
                    type="text"
                    value={newCandidate.name}
                    onChange={(e) => setNewCandidate({ ...newCandidate, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Course/Department *
                  </label>
                  <input
                    type="text"
                    value={newCandidate.course}
                    onChange={(e) => setNewCandidate({ ...newCandidate, course: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    required
                  />
                </div>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Photo URL (optional)
                </label>
                <input
                  type="url"
                  value={newCandidate.photo_url}
                  onChange={(e) => setNewCandidate({ ...newCandidate, photo_url: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="https://example.com/photo.jpg"
                />
              </div>
              <div className="flex gap-3">
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  Add Candidate
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(false);
                    setNewCandidate({ name: '', course: '', photo_url: '' });
                  }}
                  className="px-6 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading candidates...</p>
            </div>
          ) : candidates.length === 0 ? (
            <div className="text-center py-12 text-gray-600">
              No candidates added yet. Click "Add Candidate" to get started.
            </div>
          ) : (
            <div className="space-y-3">
              {candidates.map((candidate) => (
                <div
                  key={candidate.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-800">{candidate.name}</h3>
                    <p className="text-gray-600">{candidate.course}</p>
                    <p className="text-sm text-blue-600 font-medium mt-1">
                      Votes: {candidate.vote_count}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteCandidate(candidate.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete candidate"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
