import { createContext, useContext, useState, ReactNode } from 'react';
import { Student, Admin } from '../lib/supabase';

interface AuthContextType {
  currentStudent: Student | null;
  currentAdmin: Admin | null;
  loginStudent: (student: Student) => void;
  loginAdmin: (admin: Admin) => void;
  logout: () => void;
  isStudent: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [currentAdmin, setCurrentAdmin] = useState<Admin | null>(null);

  const loginStudent = (student: Student) => {
    setCurrentStudent(student);
    setCurrentAdmin(null);
  };

  const loginAdmin = (admin: Admin) => {
    setCurrentAdmin(admin);
    setCurrentStudent(null);
  };

  const logout = () => {
    setCurrentStudent(null);
    setCurrentAdmin(null);
  };

  const value = {
    currentStudent,
    currentAdmin,
    loginStudent,
    loginAdmin,
    logout,
    isStudent: !!currentStudent,
    isAdmin: !!currentAdmin,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
