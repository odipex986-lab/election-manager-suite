# College Election System

A full-stack web application for conducting secure college elections where students can vote for candidates online.

## Features

- **Student Login & Voting**: Students log in with their credentials and cast votes
- **One Vote Per Student**: System ensures each student can only vote once
- **Real-time Results**: View live vote counts and standings
- **Admin Panel**: Manage candidates, view results, and reset elections
- **Secure & Anonymous**: Votes are recorded securely and anonymously
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Tech Stack

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Supabase (PostgreSQL database)
- **Build Tool**: Vite
- **Icons**: Lucide React

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open your browser and navigate to the local server URL shown in the terminal

## Demo Credentials

### Students
- **Student ID**: STU001, STU002, STU003, STU004, or STU005
- **Password**: pass123

### Admin
- **Username**: admin
- **Password**: admin123

## Usage Guide

### For Students

1. Click "Student Login to Vote" on the home page
2. Enter your Student ID and password
3. Browse the candidates and click "Vote" on your preferred candidate
4. Your vote will be recorded and you'll be redirected to the results page

### For Administrators

1. Click "Admin Login" on the home page
2. Enter admin credentials
3. From the admin panel you can:
   - Add new candidates with name, course, and photo
   - Delete existing candidates
   - Reset the entire election (clears all votes)
   - View vote counts for each candidate

## Database Schema

### Tables

- **students**: Stores student credentials and voting status
- **candidates**: Stores candidate information and vote counts
- **votes**: Records each vote cast (for audit purposes)
- **admins**: Stores admin credentials

## Security Features

- Row Level Security (RLS) enabled on all database tables
- Password verification for login
- One-time voting enforcement
- Admin-only access for managing candidates

## Project Structure

```
/project
  /src
    /contexts
      AuthContext.tsx       # Authentication state management
    /lib
      supabase.ts          # Database client and types
    /pages
      Home.tsx             # Landing page
      Login.tsx            # Student/Admin login
      VotePage.tsx         # Voting interface
      Results.tsx          # Election results
      Admin.tsx            # Admin panel
    App.tsx                # Main app with routing
    main.tsx              # App entry point
  index.html              # HTML template
  package.json            # Dependencies
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Future Enhancements

- Email notifications for election start/end
- Multiple simultaneous elections
- Candidate profiles with manifestos
- Vote analytics and demographics
- Export results to PDF/CSV
