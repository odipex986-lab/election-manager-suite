import { useState, useEffect } from 'react';
import { CheckCircle, User, AlertCircle } from 'lucide-react';
import { supabase, Candidate } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface VotePageProps {
  onNavigate: (page: string) => void;
}

export default function VotePage({ onNavigate }: VotePageProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [voting, setVoting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const { currentStudent, logout } = useAuth();

  useEffect(() => {
    if (!currentStudent) {
      onNavigate('login');
      return;
    }
    loadCandidates();
  }, [currentStudent, onNavigate]);

  const loadCandidates = async () => {
    try {
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .order('name');

      if (error) throw error;
      setCandidates(data || []);
    } catch (err) {
      setError('Failed to load candidates');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleVote = async (candidateId: string) => {
    if (!currentStudent) return;

    setVoting(true);
    setError('');

    try {
      const { error: voteError } = await supabase
        .from('votes')
        .insert({
          student_id: currentStudent.id,
          candidate_id: candidateId,
        });

      if (voteError) throw voteError;

      const { error: updateStudentError } = await supabase
        .from('students')
        .update({ has_voted: true })
        .eq('id', currentStudent.id);

      if (updateStudentError) throw updateStudentError;

      const { error: updateCandidateError } = await supabase.rpc('increment', {
        row_id: candidateId,
        x: 1,
        table_name: 'candidates',
        column_name: 'vote_count',
      });

      if (updateCandidateError) {
        const candidate = candidates.find((c) => c.id === candidateId);
        if (candidate) {
          await supabase
            .from('candidates')
            .update({ vote_count: candidate.vote_count + 1 })
            .eq('id', candidateId);
        }
      }

      setSuccess(true);
      setTimeout(() => {
        logout();
        onNavigate('results');
      }, 2000);
    } catch (err) {
      setError('Failed to record vote. Please try again.');
      console.error(err);
    } finally {
      setVoting(false);
    }
  };

  if (!currentStudent) {
    return null;
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Vote Recorded!</h2>
          <p className="text-gray-600">Thank you for participating in the election.</p>
          <p className="text-sm text-gray-500 mt-4">Redirecting to results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Cast Your Vote</h1>
              <p className="text-gray-600 mt-1">
                Logged in as: <span className="font-semibold">{currentStudent.name}</span>
              </p>
            </div>
            <button
              onClick={() => {
                logout();
                onNavigate('home');
              }}
              className="px-4 py-2 text-sm bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors"
            >
              Logout
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4 flex items-start rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading candidates...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {candidates.map((candidate) => (
              <div
                key={candidate.id}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="aspect-square bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                  {candidate.photo_url ? (
                    <img
                      src={candidate.photo_url}
                      alt={candidate.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="w-24 h-24 text-blue-400" />
                  )}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{candidate.name}</h3>
                  <p className="text-gray-600 mb-4">{candidate.course}</p>
                  <button
                    onClick={() => handleVote(candidate.id)}
                    disabled={voting}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {voting ? 'Processing...' : 'Vote'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
