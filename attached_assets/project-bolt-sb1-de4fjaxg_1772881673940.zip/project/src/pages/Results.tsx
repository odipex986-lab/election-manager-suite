import { useState, useEffect } from 'react';
import { Trophy, TrendingUp, Users } from 'lucide-react';
import { supabase, Candidate } from '../lib/supabase';

interface ResultsProps {
  onNavigate: (page: string) => void;
}

export default function Results({ onNavigate }: ResultsProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalVotes, setTotalVotes] = useState(0);

  useEffect(() => {
    loadResults();
  }, []);

  const loadResults = async () => {
    try {
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .order('vote_count', { ascending: false });

      if (error) throw error;

      setCandidates(data || []);
      const total = data?.reduce((sum, candidate) => sum + candidate.vote_count, 0) || 0;
      setTotalVotes(total);
    } catch (err) {
      console.error('Failed to load results:', err);
    } finally {
      setLoading(false);
    }
  };

  const getPercentage = (votes: number) => {
    if (totalVotes === 0) return 0;
    return ((votes / totalVotes) * 100).toFixed(1);
  };

  const winner = candidates[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
                <TrendingUp className="w-8 h-8 text-blue-600" />
                Election Results
              </h1>
              <p className="text-gray-600 mt-1">Live vote count and standings</p>
            </div>
            <button
              onClick={() => onNavigate('home')}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              Back to Home
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Total Votes</p>
                <p className="text-2xl font-bold text-gray-800">{totalVotes}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Trophy className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Candidates</p>
                <p className="text-2xl font-bold text-gray-800">{candidates.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-4">
              <div className="bg-yellow-100 p-3 rounded-lg">
                <Trophy className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-gray-600 text-sm">Leading</p>
                <p className="text-lg font-bold text-gray-800 truncate">
                  {winner?.name || 'No votes yet'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading results...</p>
          </div>
        ) : candidates.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <p className="text-gray-600 text-lg">No candidates available yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {candidates.map((candidate, index) => (
              <div
                key={candidate.id}
                className={`bg-white rounded-xl shadow-lg p-6 ${
                  index === 0 ? 'border-2 border-yellow-400' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    {index === 0 && (
                      <div className="bg-yellow-100 p-2 rounded-full">
                        <Trophy className="w-6 h-6 text-yellow-600" />
                      </div>
                    )}
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                        {candidate.name}
                        {index === 0 && totalVotes > 0 && (
                          <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">
                            Leading
                          </span>
                        )}
                      </h3>
                      <p className="text-gray-600">{candidate.course}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-blue-600">{candidate.vote_count}</p>
                    <p className="text-sm text-gray-600">votes</p>
                  </div>
                </div>

                <div className="relative">
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${getPercentage(candidate.vote_count)}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    {getPercentage(candidate.vote_count)}% of total votes
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 bg-white rounded-xl shadow-lg p-6 text-center">
          <button
            onClick={loadResults}
            className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
          >
            Refresh Results
          </button>
        </div>
      </div>
    </div>
  );
}
