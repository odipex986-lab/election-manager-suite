import { Vote } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-8 text-white text-center">
          <div className="flex justify-center mb-4">
            <Vote className="w-16 h-16" />
          </div>
          <h1 className="text-4xl font-bold mb-2">College Election System</h1>
          <p className="text-blue-100 text-lg">Your Voice, Your Choice</p>
        </div>

        <div className="p-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Election Information</h2>
            <div className="space-y-3 text-gray-600">
              <p className="flex items-start">
                <span className="font-semibold mr-2">•</span>
                <span>Each student can cast only ONE vote for their preferred candidate</span>
              </p>
              <p className="flex items-start">
                <span className="font-semibold mr-2">•</span>
                <span>Login using your Student ID and password</span>
              </p>
              <p className="flex items-start">
                <span className="font-semibold mr-2">•</span>
                <span>Review all candidates carefully before casting your vote</span>
              </p>
              <p className="flex items-start">
                <span className="font-semibold mr-2">•</span>
                <span>Your vote is anonymous and cannot be changed once submitted</span>
              </p>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-8">
            <h3 className="font-semibold text-blue-900 mb-2">Demo Credentials</h3>
            <p className="text-sm text-blue-800">Student ID: STU001, STU002, STU003, STU004, or STU005</p>
            <p className="text-sm text-blue-800">Password: pass123</p>
            <p className="text-sm text-blue-800 mt-2">Admin - Username: admin, Password: admin123</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => onNavigate('login')}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-6 rounded-lg transition-colors shadow-lg"
            >
              Student Login to Vote
            </button>
            <button
              onClick={() => onNavigate('results')}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-4 px-6 rounded-lg transition-colors shadow-lg"
            >
              View Results
            </button>
            <button
              onClick={() => onNavigate('admin-login')}
              className="flex-1 bg-gray-600 hover:bg-gray-700 text-white font-semibold py-4 px-6 rounded-lg transition-colors shadow-lg"
            >
              Admin Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
