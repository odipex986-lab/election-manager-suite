import { useState } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import Home from './pages/Home';
import Login from './pages/Login';
import VotePage from './pages/VotePage';
import Results from './pages/Results';
import Admin from './pages/Admin';

type Page = 'home' | 'login' | 'admin-login' | 'vote' | 'results' | 'admin';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={setCurrentPage} />;
      case 'login':
        return <Login onNavigate={setCurrentPage} />;
      case 'admin-login':
        return <Login onNavigate={setCurrentPage} isAdmin />;
      case 'vote':
        return <VotePage onNavigate={setCurrentPage} />;
      case 'results':
        return <Results onNavigate={setCurrentPage} />;
      case 'admin':
        return <Admin onNavigate={setCurrentPage} />;
      default:
        return <Home onNavigate={setCurrentPage} />;
    }
  };

  return (
    <AuthProvider>
      {renderPage()}
    </AuthProvider>
  );
}

export default App;
